
//
 // Card_Module Aplication File
 // card.c
 // Tarik Zaki Mohamed (tarik.z.ramadan@gmail.com)
 // Application card_Module (card.c) 
 // Start date DD/MM/YYYY 05-11-2022
 // Testing date DD/MM/YYYY 15-11-2022
 // Finish date DD/MM/YYYY 16-11-2022
 // Copyrights (c) Tarik Zaki Mohamed
 // 
 //


 
// ============================= System Header Files Section ======================== //
#include <stdio.h> //using Printf()

#include <string.h>  // using strcpy(), strcmp()
#include <stdlib.h>
#include <ctype.h>  // using isdigit()
// ============================= System Header Files Section ======================== //

// ============================= Start User Header Files Section ======================== //
#include "../Card/Card.h"

 // ============================= End User Header Files Section ======================== //
 
// ============= Implement getCardHolderName function ============= //
EN_cardError_t getCardHolderName(ST_cardData_t *cardData)
{
	// ==  Enumerator CardHolder_ErrorState with states == //
	// === (CARD_OK,WRONG_NAME, WRONG_EXP_DATE, WRONG_PAN) and initionate it with first element == //
    EN_cardError_t CardHolder_ErrorState = CARD_OK; 

// === define Cardholder name with 24 characters + '\0' == //
    uint8_t CardHolderName[25] = {0}; 

    printf("\n Enter the card holder name: ");
    gets(CardHolderName);
    uint8_t NameLength = strlen(CardHolderName);

// === check if Cardholdername is between 24 alphabetic characters string max and 20 minimum == //
    if( (NULL == CardHolderName) || 
        (NameLength < 20) || 
        (NameLength > 24) )
    {
// === If the cardholder name is NULL, less than 20 characters or more == //
// === than 24 will return a WRONG_NAME error, else return CARD_OK == //
	    CardHolder_ErrorState = WRONG_NAME;
    }
    else 
    {
    	strcpy(cardData->cardHolderName, CardHolderName);
    	CardHolder_ErrorState = CARD_OK;
    }

    return CardHolder_ErrorState;
}
// ============= End getCardHolderName function ============= //
 
// ============= Implement getCardExpiryDate function ============= // 
 
EN_cardError_t getCardExpiryDate(ST_cardData_t *cardData)
{
	// == Enumerator CardExpiryDate_ErrorState with states == //
	// === (CARD_OK,WRONG_NAME, WRONG_EXP_DATE, WRONG_PAN) and initionate it with first element == //
    EN_cardError_t CardExpiryDate_ErrorState = CARD_OK;

// === define cardExpirationDate with 5 characters + '/0' // 
    uint8_t cardExpirationDate[6] = {0};

    printf("\n Enter the card expiration date: as MM/YY ");
    gets(cardExpirationDate);
    uint8_t DateLength = strlen(cardExpirationDate);

// === check if the card expiry date is NULL, less or more than 5 characters, == //
// === or has the wrong format like not numbers or miss '/' in its correct position == //
// === isdigit() Result when numeric character is passed: 1 == //
// === isdigit() Result when non-numeric character is passed: 0 == //
    if( (NULL == cardExpirationDate) || (cardExpirationDate[2] != '/')||
        (DateLength != 5) || (isdigit(cardExpirationDate[0]) != 1) ||
       (isdigit(cardExpirationDate[1]) != 1) || (isdigit(cardExpirationDate[3]) != 1) || 
	   (isdigit(cardExpirationDate[4]) != 1) )
	   
    {
		// === if the card expiry date is NULL, less or more than 5 characters, or has the wrong format == //
		// === will return the WRONG_EXP_DATE error, else return CARD_OK == //
        CardExpiryDate_ErrorState = WRONG_EXP_DATE;
    }
    else
    {
       strcpy(cardData->cardExpirationDate, cardExpirationDate);
       CardExpiryDate_ErrorState = CARD_OK;
    }
    return CardExpiryDate_ErrorState;
}
// ============= End getCardExpiryDate function ============= // 


// ============= Implement getCardPAN function ============= // 

EN_cardError_t getCardPAN(ST_cardData_t *cardData)
{
	// ===  Enumerator getCardPAN_ErrorState with states(CARD_OK,WRONG_NAME, WRONG_EXP_DATE, WRONG_PAN) == //
	// === and initionate it with first element == //
    EN_cardError_t getCardPAN_ErrorState = CARD_OK;
    
// === define cardPAN with 19 characters + '\0' == //
    uint8_t cardPAN[20] = {0};
    printf("\n Enter the card primary account number: ");
    gets(cardPAN);
    uint8_t PANLength = strlen(cardPAN);

// === check if the cardPAN is NULL, less 16 or more than 19 characters == //
	// === check if the cardPAN is NULL, less 16 or more than 19 characters == //
    // === will return the WRONG_PAN, else return CARD_OK == //
    if( (NULL == cardPAN) || 
        (PANLength < 16) || 
        (PANLength > 19) )
    {
        getCardPAN_ErrorState = WRONG_PAN;
    }
    else
    {
    	strcpy(cardData->primaryAccountNumber, cardPAN);
        getCardPAN_ErrorState = CARD_OK;
    }
    return getCardPAN_ErrorState;
}
// ============= End getCardPAN function ============= // 


// ============= Implement Test functions =================== // 
// ============= Implement getCardHolderNameTest function ============= //

void getCardHolderNameTest(void)
{
	ST_cardData_t testCard;
	const int lenght = 5;

	// === list of tests == //
	uint8_t namesTest[5][30] = { "Tarik Zaki M. M. Ramadan(24)","Ahmed Ibrahim(13)","Mohamed Omar Ali El sayed(25)","Omar Ibrahim Mohamed(20)","'\0' null (20)" };

	// === list of expected output == //
	uint8_t expectedOutputs[5][11] = { "CARD_OK","WRONG_NAME","WRONG_NAME","CARD_OK","WRONG_NAME"};
	printf("Tester Name: Tarik Zaki M. M. Ramadan\n");
	printf("Function Name: getCardHolderName\n");
	for (int i = 0; i < lenght; i++)
	{
		printf("Test Case %d: %s \n", i + 1, namesTest[i]);
		printf("Expected Result: %s ", expectedOutputs[i]);
		printf("Actual Result: %s \n \n", getCardHolderName(&testCard) == CARD_OK ? "CARD_OK" : "WRONG_NAME");
	}
}
// ============== End getCardHolderNameTest function ============= //


// ============= Implement getCardExpiryDateTest function ============= //
void getCardExpiryDateTest(void)
{
	ST_cardData_t testCard;
	const int lenght = 5;

	// === list of tests == //
	uint8_t datesTest[5][7] = { "11/22","1122","11/y6","112/2","1/122" };

	// === list of expected output == //
	uint8_t expectedOutputs[5][15] = { "CARD_OK","WRONG_EXP_DATE","WRONG_EXP_DATE","WRONG_EXP_DATE","WRONG_EXP_DATE" };

	printf("Tester Name: Tarik Zaki M. M. Ramadan\n");
	printf("Function Name: getCardExpiryDate\n");
	for (int i = 0; i < lenght; i++)
	{
		printf("Test Case %d: %s \n", i + 1, datesTest[i]);
		printf("Expected Result: %s ", expectedOutputs[i]);
		printf("Actual Result: %s \n \n", getCardExpiryDate(&testCard) == CARD_OK ? "CARD_OK" : "WRONG_EXP_DATE");
	}
}
// ============= End getCardExpiryDateTest function ============= //

// ============= Implement getCardPANTest function ============= //

void getCardPANTest(void)
{
	ST_cardData_t testCard;
	const int lenght = 4;

	// === list of tests == //
	uint8_t PANTest[4][21] = { "2769148304059987","98984958","\0 null","27691483040599871255" };

	// === list of expected output == //
	uint8_t expectedOutputs[4][10] = { "CARD_OK","WRONG_PAN","WRONG_PAN","WRONG_PAN" };

	printf("Tester Name: Tarik Zaki M. M. Ramadan\n");
	printf("Function Name: getCardPAN\n");
	for (int i = 0; i < lenght; i++)
	{
		printf("Test Case %d: %s \n", i + 1, PANTest[i]);
		printf("Expected Result: %s ", expectedOutputs[i]);
		printf("Actual Result: %s \n \n", getCardPAN(&testCard) == CARD_OK ? "CARD_OK" : "WRONG_PAN");
	}
}
// ============= End getCardPANTest function ============= //


// ============= End Test functions =================== // 



