//====================== this file for attention ======================//

this project is compiled by Embarcadero Dev-C++, and tested and run on windows 7
on 16-Nov-2022

this IDE is a full-featured Integrated Development Environment (IDE) and code editor for the C/C++ programming language.

to open project please click on .dev file after downloading the programming IDE
the link to download is:

https://www.embarcadero.com/free-tools/dev-cpp/free-download

after writing your information, download will start immediately




